<?php
class MyDate {
    private $day, $month, $year;

    public function __construct($d, $m, $y) {
        $this->day = $d;
        $this->month = $m;
        $this->year = $y;
    }

    public function calcDay() {
        $totalDay = $this->day;
        for ($i = 1; $i < $this->month; $i++) {
            switch($i) {
                case 1:
                    $totalDay += 31;
                    break;
                case 2:
                    if ($this->year % 400 == true || $this->year % 4 == 0 && $this->year % 100 != 0) {
                        $totalDay += 29;
                    } else {
                        $totalDay += 28;
                    }
                    break;
                case 3:
                    $totalDay += 31;
                    break;
                case 4:
                    $totalDay += 30;
                    break;
                case 5:
                    $totalDay += 31;
                    break;
                case 6:
                    $totalDay += 30;
                    break;
                case 7:
                    $totalDay += 31;
                    break;
                case 8:
                    $totalDay += 31;
                    break;
                case 9:
                    $totalDay += 30;
                    break;
                case 10:
                    $totalDay += 31;
                    break;
                case 11:
                    $totalDay += 30;
                    break;
                case 12:
                    $totalDay += 31;
                    break;
            }      
        }
        return $totalDay;
    }
}

$myDate = new MyDate(11, 9, 2021);
$totalDay = $myDate->calcDay();
echo "Ngày từ đầu năm đến ngày vừa nhập là: ".$totalDay;
?>